%
% Filename: $RCSfile: prep_integ_masks.m,v $
%
% $Revision: 1.8 $  $Date: 2011/11/15 17:50:35 $
% $Author: ikonen $
% $Tag: $
%
% Description:
% prepare masks for the radial integration of SAXS patterns
%
% Note:
% Call without arguments for a brief help text.
%
% Dependencies: 
% - image_read
% - pilatus_valid_pixel_roi
%
% history:
%
% September 4th 2009, Oliver Bunk:
% correct in help text one of the RadiusFrom to RadiusTo
%
% May 9th 2008, Oliver Bunk: 1st documented version
%
function [ integ_masks ] = prep_integ_masks(filename, center_xy, varargin)


% initialize return arguments
integ_masks = struct('radius',[], 'indices',[], 'norm_sum', []);

% set default values for the variable input arguments:
% integration range
r_from = 1;
r_step = 1;
r_to = 0;
% number of angular segments per radius
no_of_segments = 1;
% output directory for the masks
out_dir = '~/Data10/analysis/data/';
filename_valid_mask = [ out_dir 'pilatus_valid_mask.mat' ];
filename_integ_masks = [ out_dir 'pilatus_integration_masks.mat' ];
% angular range to be excluded to cut out the beam stop
bs_angle_from = 0;
bs_angle_to = 0;
% output figure number
fig_no = 240;
% save integration masks
save_data = 1;
% display valid pixel mask
display_valid_mask = 1;

% check minimum number of input arguments
if (nargin < 2)
    fprintf('\nUsage:\n');
    fprintf('[integ_masks]=%s( filename, center_xy [[,<name>,<value>]...]);\n',mfilename);
    fprintf('Prepare the masks for an efficient radial integration.\n');
    fprintf('The optional angular range in degree can be used to cut out a beam stop.\n');
    fprintf('Angle 0 is horizontally to the left, positive in counterclockwise direction.\n');
    fprintf('The specified data file is loaded and some of the integration masks are plotted into that frame.\n');
    fprintf('\n');
    fprintf('The optional <name>,<value> pairs are:\n');
    fprintf('''RadiusFrom'',<integer>              radial integration start radius, default is %d\n',r_from);
    fprintf('''RadiusStep'',<integer>              radial integration step size, default is %d\n',r_step);
    fprintf('''RadiusTo'',<integer>                radial integration end radius, default is %d\n',r_to);
    fprintf('''NoOfSegments'',<integer>            Number of angular segments. If an integer, this number of equally wide azimuthal\n')
    fprintf('                                    bins over 360 degrees are created.\n');
    fprintf('                                    If this value is a vector, its elements are interpreted as angles\n');
    fprintf('                                    in degrees, giving the borders of continuous azimuthal bins. If there are N\n');
    fprintf('                                    elements in the array, N-1 bins are created. Bins grow in positive direction, i.e.\n')
    fprintf('                                    [-5, 5] creates a 10 deg wide bin, not 350 deg. Default is %d\n', no_of_segments);
    fprintf('''BeamstopAngleFrom'',<float>         exclude an angular region from the integration, default for the start value is %d\n',...
        bs_angle_from);
    fprintf('''BeamstopAngleTo'',<float>           exclude an angular region from the integration, default for the end value is %d\n',...
        bs_angle_to);
    fprintf('''SaveData'',<0-no,1-yes>             save the integration masks, default is %d\n',save_data);
    fprintf('''FilenameValidMask'',<path and filename>  Matlab file with the valid pixel indices ind_valid,\n');
    fprintf('                                    default is %s\n',filename_valid_mask);
    fprintf('''FilenameIntegMasks'',<path and filename> output file name for the structure integ_masks,\n');
    fprintf('                                    default is %s\n',filename_integ_masks);
    fprintf('''FigNo'',<integer>                   number of the figure in which the result is displayed\n');
    fprintf('\n');
    fprintf('\n');
    fprintf('The file name should be the name of a single file without wildcards\n');
    fprintf('that is displayed as an example.\n');
    fprintf('The image file has no other function beyond being displayed as example.\n');
    fprintf('Example:\n');
    fprintf('[integ_masks]=%s(''~/Data10/pilatus/image.cbf'',[512 512]);\n',...
        mfilename);

    error('At least the filename and the beam center have to be specified as input parameter.');
end

% check number of center coordinates
if (length(center_xy) ~= 2)
    error('The beam center needs to be specified as a two component vector [cen_x cen_y].\n');
end
center_x = center_xy(1);
center_y = center_xy(2);

% accept cell array with name/value pairs as well
no_of_in_arg = nargin;
if (nargin == 3)
    if (isempty(varargin))
        % ignore empty cell array
        no_of_in_arg = no_of_in_arg -1;
    else
        if (iscell(varargin{1}))
            % use a filled one given as first and only variable parameter
            varargin = varargin{1};
            no_of_in_arg = 2 + length(varargin);
        end
    end
end

% check number of input arguments
if (rem(no_of_in_arg,2) ~= 0)
    error('The optional parameters have to be specified as ''name'',''value'' pairs');
end


% parse the variable input arguments
vararg = cell(0,0);
for ind = 1:2:length(varargin)
    name = varargin{ind};
    value = varargin{ind+1};
    switch name
        case 'RadiusFrom' 
            r_from = value;
        case 'RadiusStep' 
            r_step = value;
        case 'RadiusTo' 
            r_to = value;
        case 'NoOfSegments' 
            no_of_segments = value;
        case 'BeamstopAngleFrom' 
            bs_angle_from = value;
        case 'BeamstopAngleTo' 
            bs_angle_to = value;
        case 'FilenameValidMask' 
            filename_valid_mask = value;
        case 'FilenameIntegMasks' 
            filename_integ_masks = value;
        case 'SaveData' 
            save_data = value;
        case 'DisplayValidMask' 
            display_valid_mask = value;
        case 'FigNo' 
            fig_no = value;
        otherwise
            vararg{end+1} = name;
            vararg{end+1} = value;
    end
end

% check radius
if (r_from < 1)
    error('The minimum radius is 1, %d is invalid.',r_from);
end
if ((r_to ~= 0) && (r_to < r_from))
    error('The maximum radius must be greater than the minimum one, %d is invalid.\n',r_to);
end

% check number of angular segments
if (no_of_segments < 1)
    error('The number of angular segments must be at least 1');
end
if (numel(no_of_segments)>1)
    angular_segments = no_of_segments;
    no_of_segments = numel(no_of_segments)-1;
else
    angular_segments = 360/no_of_segments * (0:no_of_segments);
end
angular_segments = mod(angular_segments, 360);

% check beamstop region
if ((bs_angle_from < 0.0) || (bs_angle_to > 360.0))
    error('The angular range for the beam stop region is 0 to 360 degree.');
end
if (bs_angle_to < bs_angle_from)
    error('The maximum beam stop angle must be less than or equal to the minimum one.\n');
end

% load the indices of valid pixels
fprintf('loading the valid pixel mask %s\n',filename_valid_mask);
load(filename_valid_mask);
dim_x = valid_mask.framesize(2);
dim_y = valid_mask.framesize(1);


if (~isempty(filename))
    % load test frame
    frame = image_read(filename,vararg);
    % select the first frame for display
    frame.data = frame.data(:,:,1);
    % in case of less than full detector readout cut out the right part of 
    % the valid pixel mask
    valid_mask = pilatus_valid_pixel_roi(valid_mask,'RoiSize',size(frame.data));
    dim_x = size(frame.data,2);
    dim_y = size(frame.data,1);
end

% plot valid pixel mask
if (display_valid_mask)
    figure(fig_no);
    vpm = zeros(dim_y,dim_x);
    vpm(valid_mask.indices) = 1;
    imagesc(vpm);
    axis xy;
    axis equal;
    axis tight;
    title('valid pixels');
    set(gcf,'Name','valid pixels');
    drawnow;
end

% choose maximum radius, if specified via r_to=0
if (r_to < 1)
    r_to = max( [ sqrt(center_x^2+center_y^2) ...
                  sqrt((dim_x-center_x)^2+center_y^2) ...
                  sqrt(center_x^2+(dim_y-center_y)^2) ...
                  sqrt((dim_x-center_x)^2+(dim_y-center_y)^2) ] );
end

fprintf('preparing the integration masks ...\n');

% create an array of the (x,y) coordinates relative to the beam center and
% convert it to polar coordinates
[ x, y ] = meshgrid( (1:dim_x)-center_x, (1:dim_y)-center_y );
[ theta, rho ] = cart2pol( x, y );
% convert angular range from -pi/pi to 0/360
theta = (theta/pi +1) * 180.0;

% prepare circular masks of the integer width r_step (in pixel)
integ_masks.radius = r_from:r_step:r_to;
no_of_radii = length(integ_masks.radius);
integ_masks.indices = cell( no_of_radii, no_of_segments );
integ_masks.norm_sum = zeros( no_of_radii, no_of_segments );
seg_inds = cell(no_of_segments,1);
for ind_seg = 1:no_of_segments
    seg_from = angular_segments(ind_seg);
    seg_to   = angular_segments(ind_seg+1);
    if (seg_from >= seg_to)
        ind_curr = find( ((theta > seg_from) | (theta <= seg_to) ) & ...
                         ((theta <= bs_angle_from) | (theta >= bs_angle_to)) );
    else
        ind_curr = find( ((theta > seg_from) & (theta <= seg_to) ) & ...
                         ((theta <= bs_angle_from) | (theta >= bs_angle_to)) );
    end
    % only take valid pixels into account
    ind_curr = intersect(ind_curr, valid_mask.indices);
    seg_inds{ind_seg} = ind_curr;
end

for ind_r=1:no_of_radii
    if (rem(ind_r,100) == 0)
        fprintf('%4d / %d',ind_r,no_of_radii);
        if (ind_r <= no_of_radii-100)
            fprintf(', ');
        end
    end
    r_inds = find( (rho >= integ_masks.radius(ind_r)) & ...
                   (rho < integ_masks.radius(ind_r)+r_step) );
    for ind_seg = 1:no_of_segments
        integ_masks.indices{ind_r, ind_seg} = intersect( r_inds, seg_inds{ind_seg} );
        % calculate the normalization value (sum of the pixels within the mask)
        integ_masks.norm_sum(ind_r, ind_seg) = ...
            length( integ_masks.indices{ind_r, ind_seg} );
    end
end
fprintf('\n');

% save integration masks
if (save_data)
    fprintf('Saving center_xy, no_of_segments, integ_masks to %s\n',...
        filename_integ_masks);
    save(filename_integ_masks,'center_xy','no_of_segments','integ_masks');
end

% display some integration circles
if (~isempty(filename))
    figure(fig_no+1);
    hold off;
    clf;
    frame_plot = frame.data;
    frame_plot( frame_plot < 1 ) = 1;

    plot_step = round(length(integ_masks.indices)/50);
    if (plot_step < 2)
        plot_step = 2;
    end
    for (ind_r = 1:plot_step:size(integ_masks.indices,1))
        for (ind_seg = 1:2:no_of_segments)
            frame_plot(integ_masks.indices{ind_r,ind_seg}) = 10^(6*ind_seg/no_of_segments);
        end
    end
    if (bs_angle_from ~= bs_angle_to)
        frame_plot( (abs(theta-bs_angle_from+0.5) < 0.5) | (abs(theta-bs_angle_to-0.5) < 0.5) ) = 1e6;
    end
    
    imagesc(log10(frame_plot));
    axis xy;
    axis equal;
    axis tight;
    colorbar;
    title([ 'integration segment test plot for ' strrep(filename,'_','\_') ]);
    set(gcf,'Name','integration masks');
end
